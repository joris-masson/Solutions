x = float(input("Note 1: "))
y = float(input("Note 2: "))
z = float(input("Note 3: "))

moyenne = (x+y+z)/3
print("moyenne: ", moyenne)
