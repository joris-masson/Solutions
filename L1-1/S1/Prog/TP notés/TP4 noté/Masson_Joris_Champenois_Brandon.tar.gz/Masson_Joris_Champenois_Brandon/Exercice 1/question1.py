entier = int(input("Entrez un entier: "))

for i in range(1, entier):
    print("le nombre qui suit", i, "est", i+1) 
