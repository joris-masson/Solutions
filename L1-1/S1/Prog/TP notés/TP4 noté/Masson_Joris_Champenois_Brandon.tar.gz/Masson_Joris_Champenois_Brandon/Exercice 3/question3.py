etudiants = ("pierre","paul","mohamed","lucie","anne","sophie","lucas","louane","maria","romain","celine","justine","ali","tom","dylan")

for personne in range(len(etudiants)):
    if etudiants[personne][0] == 'l':
        print(etudiants[personne])

