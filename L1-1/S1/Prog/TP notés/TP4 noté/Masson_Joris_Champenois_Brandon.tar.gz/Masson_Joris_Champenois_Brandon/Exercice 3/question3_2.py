etudiants = ("pierre","paul","mohamed","lucie","anne","sophie","lucas","louane","maria","romain","celine","justine","ali","tom","dylan")

for personne in range(len(etudiants)):
    if 'l' in etudiants[personne]:
        print(etudiants[personne])
